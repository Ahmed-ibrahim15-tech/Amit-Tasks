
let x = 70;


if (x > 100) {
    console.log("Invalid grade")
} 
else if (x >= 85) {
    console.log("Excellent")
}
 else if (x >= 75) {
    console.log("Very Good")
} 
else if (x >= 65) {
    console.log("Good")
} 
else if (x >= 55) {
    console.log("Passed")
} 
else {
    console.log("Failed")
}
